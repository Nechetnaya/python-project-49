#!/usr/bin/env python3


from brain_games.game import lets_play


def main():
    game_name = 'even'
    lets_play(game_name)
