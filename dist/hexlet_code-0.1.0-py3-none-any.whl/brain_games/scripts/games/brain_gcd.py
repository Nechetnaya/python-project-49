#!/usr/bin/env python3


from brain_games.game import lets_play


def main():
    game_name = 'gcd'
    lets_play(game_name)
