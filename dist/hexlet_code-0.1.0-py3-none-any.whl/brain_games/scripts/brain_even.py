#!/usr/bin/env python3

from brain_games.even_game import check_even



def main():
    check_even()